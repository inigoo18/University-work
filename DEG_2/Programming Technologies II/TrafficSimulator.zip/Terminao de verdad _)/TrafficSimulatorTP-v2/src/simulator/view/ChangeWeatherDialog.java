package simulator.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

import simulator.model.Road;

import simulator.model.Weather;

public class ChangeWeatherDialog extends JDialog {
	private static final int _WIDTH = 400;
	private static final int _HEIGHT = 150;
	
	private int _status;
	private JComboBox<String> _roads;
	private JComboBox<Weather> _weather;
	private JSpinner _ticks;
	
	ChangeWeatherDialog(Frame parent){
		super(parent, true);
		initGUI();
	}
	
	private void initGUI() {
		setTitle("Change Road Weather");
		JPanel mainPanel = new JPanel(new BorderLayout());

		JLabel message = new JLabel("<html>Schedule an event to change the weather of a road after a given number of simulation ticks from now.<html>");
		mainPanel.add(message, BorderLayout.PAGE_START);
		
		JPanel centerPanel = new JPanel();
		
		JLabel roadLabel = new JLabel("Road:");
		_roads = new JComboBox<String>();
		
		JLabel weatherLabel = new JLabel("Weather:");
		_weather = new JComboBox<Weather>(Weather.values());
		_weather.setSelectedIndex(0);
		
		JLabel ticksLabel = new JLabel("Ticks:");
		_ticks = new JSpinner(new SpinnerNumberModel(1, 1, 10000, 1));
		_ticks.setPreferredSize(new Dimension(60, 20));
		
		centerPanel.add(roadLabel);
		centerPanel.add(_roads);
		centerPanel.add(weatherLabel);
		centerPanel.add(_weather);
		centerPanel.add(ticksLabel);
		centerPanel.add(_ticks);
		mainPanel.add(centerPanel);
		
		JPanel bottomPanel = new JPanel();
		
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener((e) ->{
			setVisible(false);
		});
		
		JButton okButton = new JButton("Ok");
		okButton.addActionListener((e) ->{
			if (_roads.getSelectedItem() != null) {
                _status = 1;
                setVisible(false);
            }
		});
		
		bottomPanel.add(cancelButton);
		bottomPanel.add(okButton);
		mainPanel.add(bottomPanel, BorderLayout.PAGE_END);
		
		setContentPane(mainPanel);
		
		setVisible(false);
	}
	
	public int open(List<Road> roads) {
		for(Road r : roads) {
			_roads.addItem(r.getId());
		}
		
		int xParentLocation = getParent().getLocation().x;
		int yParentLocation = getParent().getLocation().y;
		int xParentSize = getParent().getSize().width;
		int yParentSize = getParent().getSize().height;
		
		setSize(_WIDTH, _HEIGHT);
		setLocation(xParentLocation + xParentSize / 2 - _WIDTH/2, yParentLocation + yParentSize / 2 - _HEIGHT / 2);
		setVisible(true);
		
		return _status;
	}

	String getSelectedRoad() {
		return (String) _roads.getSelectedItem();
	}
	
	Weather getSelectedWeather() {
		return (Weather) _weather.getSelectedItem();
	}
	
	int getSelectedTicks() {
		return (int) _ticks.getValue();
	}
}
