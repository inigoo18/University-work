package simulator.view;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import simulator.control.Controller;
import simulator.misc.SortedArrayList;
import simulator.model.Event;
import simulator.model.RoadMap;
import simulator.model.TrafficSimObserver;

public class EventsTableModel extends AbstractTableModel implements TrafficSimObserver {

	private int _columns = 2;
	private List<Event> eventList;
	private String[] _headers = {"Time", "Desc."};

	EventsTableModel(Controller ctrl) {
		eventList = new SortedArrayList<Event>();
		ctrl.addObserver(this);
	}

	public String getColumnName(int col) {
		return _headers[col];
	}

	@Override
	public int getRowCount() {
		return eventList.size();
	}

	@Override
	public int getColumnCount() {
		return _columns;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch (columnIndex) {
		case (0):
			return eventList.get(rowIndex).getTime();
		default:
			return eventList.get(rowIndex).toString();
		}
	}

	@Override
	public void onAdvanceStart(RoadMap map, List<Event> events, int time) {}

	@Override
	public void onAdvanceEnd(RoadMap map, List<Event> events, int time) {
		eventList = events;
		fireTableDataChanged();
	}

	@Override
	public void onEventAdded(RoadMap map, List<Event> events, Event e, int time) {
		eventList = events;
		fireTableDataChanged();
	}

	@Override
	public void onReset(RoadMap map, List<Event> events, int time) {
		eventList = new SortedArrayList<Event>();
		fireTableDataChanged();
	}

	@Override
	public void onRegister(RoadMap map, List<Event> events, int time) {
		eventList = events;
		fireTableDataChanged();
	}

	@Override
	public void onError(String err) {}

}
