package simulator.view;

import java.awt.Dimension;
import java.awt.Frame;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JToolBar;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import simulator.control.Controller;
import simulator.misc.Pair;
import simulator.model.Event;
import simulator.model.Road;
import simulator.model.RoadMap;
import simulator.model.SetContClassEvent;
import simulator.model.SetWeatherEvent;
import simulator.model.TrafficSimObserver;
import simulator.model.Vehicle;
import simulator.model.Weather;

public class ControlPanel extends JPanel implements TrafficSimObserver{
	private Controller _ctrl;
	private JFileChooser _fc;
	private JButton playButton, _loadEventsFile,_changeWeather, _changeCO2, _exitButton;
	private ChangeWeatherDialog _weatherDialog;
	private ChangeCO2ClassDialog _CO2Dialog;
	private RoadMap _roadMap;
	private JSpinner _ticks;
	private int _time = 0;
	private boolean _stopped = true;;
	
	
	ControlPanel(Controller ctrl){
		_ctrl = ctrl;
		_ctrl.addObserver(this);
		_fc = new JFileChooser();
		reset();
		
		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		
		JToolBar toolBar = new JToolBar();
		add(toolBar);
	
		initLoadEventsButton(toolBar);
		toolBar.add(Box.createRigidArea(new Dimension(5, 0)));
		toolBar.add(CreateSeparator(6, 40));
		initChangeContButton(toolBar);
		initChangeWeatherButton(toolBar);
		toolBar.add(Box.createRigidArea(new Dimension(5, 0)));
		toolBar.add(CreateSeparator(6, 40));
		initPlayButton(toolBar);
		initStopButton(toolBar);
		initTicks(toolBar);
		toolBar.add(Box.createHorizontalGlue());
		toolBar.add(CreateSeparator(6, 40));
		initExit(toolBar);
	}
	
	private JSeparator CreateSeparator(int x, int y) {
		JSeparator sep = new JSeparator(SwingConstants.VERTICAL);
		sep.setPreferredSize(new Dimension(x, y));
		sep.setMaximumSize(new Dimension(x, y));
		sep.setMinimumSize(new Dimension(x, y));
		return sep;
	}
	
	private void reset() {
		_roadMap = new RoadMap();
		_time = 0;
	}
	
	private void initLoadEventsButton(JComponent comp) {
		_loadEventsFile = new JButton();
		_loadEventsFile.setToolTipText("Load file");
		_loadEventsFile.setIcon(new ImageIcon("resources/icons/open.png"));
		_loadEventsFile.addActionListener((e) -> {
			if(_fc.showOpenDialog((Frame) SwingUtilities.getWindowAncestor(this)) == JFileChooser.APPROVE_OPTION) {
				_ctrl.reset();
				try {
					_ctrl.loadEvents(new FileInputStream(_fc.getSelectedFile()));
				} catch (Exception exc) {
					JOptionPane.showOptionDialog((Frame) SwingUtilities.getWindowAncestor(this), exc.getMessage(), "Error", JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE, null, null, null);
				}
			}
		});
		comp.add(_loadEventsFile);
	}
	
	private void initChangeContButton(JComponent comp) {
		_changeCO2 = new JButton();
		_changeCO2.setToolTipText("Change CO2 class of a vehicle.");
		_changeCO2.setIcon(new ImageIcon("resources/icons/co2class.png"));
		_changeCO2.addActionListener((e) -> {
			_CO2Dialog = new ChangeCO2ClassDialog((Frame) SwingUtilities.getWindowAncestor(this));
			if(_CO2Dialog.open(_roadMap.getVehicles()) == 1) { // Pair of string & integer
				List<Pair<String,Integer>> list = new ArrayList<Pair<String,Integer>>();
				list.add(new Pair<String, Integer>(_CO2Dialog.getSelectedVehicle(), _CO2Dialog.getSelectedContClass()));
				_ctrl.addEvent(new SetContClassEvent(_CO2Dialog.getSelectedTicks() + _time, list));
			}
		});
		comp.add(_changeCO2);
	}
	
	private void initChangeWeatherButton(JComponent comp) {
		_changeWeather = new JButton();
		_changeWeather.setToolTipText("Change weather of a road.");
		_changeWeather.setIcon(new ImageIcon("resources/icons/weather.png"));
		_changeWeather.addActionListener((e) -> {
			_weatherDialog = new ChangeWeatherDialog((Frame) SwingUtilities.getWindowAncestor(this)); // <- This method needs a Frame (MainWindow), so if we put it outside the lambda expression, 
			if(_weatherDialog.open(_roadMap.getRoads()) == 1) {													  //    it's called when ControlPanel is not yet in MainWindow
				List<Pair<String,Weather>> list = new ArrayList<Pair<String,Weather>>();
				list.add(new Pair<String, Weather>(_weatherDialog.getSelectedRoad(), _weatherDialog.getSelectedWeather()));
				_ctrl.addEvent(new SetWeatherEvent(_weatherDialog.getSelectedTicks() + _time, list));
			}
		});
		comp.add(_changeWeather);
	}
	
	private void initPlayButton(JComponent comp){
		playButton = new JButton();
		playButton.setToolTipText("Start simulation.");
		playButton.setIcon(new ImageIcon("resources/icons/run.png"));
		playButton.addActionListener((e) -> {
			_stopped = false;
			enableToolBar(false);
			run_sim((int) _ticks.getValue());
		});
		comp.add(playButton);
	}
	
	private void initStopButton(JComponent comp){
		JButton stopButton = new JButton();
		stopButton.setToolTipText("Stop simulation while its running.");
		stopButton.setIcon(new ImageIcon("resources/icons/stop.png"));
		stopButton.addActionListener((e) ->{
			stop();
			enableToolBar(true);
		});
		comp.add(stopButton);
	}
	
	private void initTicks(JComponent comp) {
		JLabel ticksLabel = new JLabel("Ticks: ");
		_ticks = new JSpinner(new SpinnerNumberModel(1, 1, 10000, 1));
		_ticks.setToolTipText("Simulation tick to run: (1-10000 ticks)");
		_ticks.setPreferredSize(new Dimension(75, 35));
		_ticks.setMaximumSize(new Dimension(75, 35));
		_ticks.setMinimumSize(new Dimension(75, 35));
		comp.add(ticksLabel);
		comp.add(_ticks);
	}
	
	private void initExit(JComponent comp) {
		_exitButton = new JButton();
		_exitButton.setToolTipText("Exit simulation.");
		_exitButton.setIcon(new ImageIcon("resources/icons/exit.png"));
		comp.add(_exitButton);
		_exitButton.addActionListener((e) -> {
			int n = JOptionPane.showOptionDialog((Frame) SwingUtilities.getWindowAncestor(this), "Are you sure you want to quit?", "Quit", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
			if (n == 0) {
				System.exit(0);
			}
		});
	}
	
	private void enableToolBar(boolean enable) {
		playButton.setEnabled(enable);
		_loadEventsFile.setEnabled(enable);
		_changeWeather.setEnabled(enable);
		_changeCO2.setEnabled(enable);
		_ticks.setEnabled(enable);
		_exitButton.setEnabled(enable);
	}
	
	private void run_sim(int n) {
		if (n > 0 && !_stopped) {
			try {
				_ctrl.run(1);
			} catch (Exception e) {
				JOptionPane.showOptionDialog((Frame) SwingUtilities.getWindowAncestor(this), e.getMessage(), "Error", JOptionPane.CLOSED_OPTION, JOptionPane.ERROR_MESSAGE, null, null, null);		
				_stopped = true;
				enableToolBar(false);
			}
			SwingUtilities.invokeLater(() -> run_sim(n - 1));
		} else {
			enableToolBar(true);
			_stopped = true;
		}
	}

	private void stop() {
		_stopped = true;
	}
	
	@Override
	public void onAdvanceStart(RoadMap map, List<Event> events, int time) {
		_time++;
	}

	@Override
	public void onAdvanceEnd(RoadMap map, List<Event> events, int time) {
		_roadMap = map;
	}

	@Override
	public void onEventAdded(RoadMap map, List<Event> events, Event e, int time) {}

	@Override
	public void onReset(RoadMap map, List<Event> events, int time) {
		reset();
	}

	@Override
	public void onRegister(RoadMap map, List<Event> events, int time) {
		_roadMap = map;
	}

	@Override
	public void onError(String err) {
	}

}
