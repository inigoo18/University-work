package simulator.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.table.AbstractTableModel;

import simulator.control.Controller;
import simulator.model.Event;
import simulator.model.Junction;
import simulator.model.Road;
import simulator.model.RoadMap;
import simulator.model.TrafficSimObserver;
import simulator.model.Vehicle;

public class JunctionTableModel extends AbstractTableModel implements TrafficSimObserver {
	
	private Controller ctrl;
	private List<Junction> junctionList;
	private String[] _headers = {"Id", "Green", "Queues"};
	
	private int _columns = 3;
	
	public JunctionTableModel(Controller _ctrl) {
		ctrl = _ctrl;
		junctionList = new ArrayList<Junction>();
		ctrl.addObserver(this);
	}

	
	public String getColumnName(int col) {
		return _headers[col];
	}
	

	@Override
	public int getRowCount() {
		return junctionList.size();
	}


	@Override
	public int getColumnCount() {
		return _columns;
	}


	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch(columnIndex) {
		case(0):
			return junctionList.get(rowIndex).getId();
		case(1):
			int idx = junctionList.get(rowIndex).getGreenLightIndex();
			if (idx != -1) {
				return junctionList.get(rowIndex).getInRoads().get(idx);
			}
			else {
				return "NONE";
			}
		case(2):
			Map<Road, List<Vehicle>> queues = junctionList.get(rowIndex).getQueues();
			String res = "";
			for (Road r : junctionList.get(rowIndex).getInRoads()) {
				res += r.toString() + ": ";
				res += queues.get(r).toString() + " ";
			}
			return res;
		default:
			return null;
		}
	}


	@Override
	public void onAdvanceStart(RoadMap map, List<Event> events, int time) {}


	@Override
	public void onAdvanceEnd(RoadMap map, List<Event> events, int time) {
		junctionList = map.getJunctions();
		fireTableDataChanged();
	}


	@Override
	public void onEventAdded(RoadMap map, List<Event> events, Event e, int time) {}


	@Override
	public void onReset(RoadMap map, List<Event> events, int time) {
		junctionList = new ArrayList<Junction>();
		fireTableDataChanged();
		
	}


	@Override
	public void onRegister(RoadMap map, List<Event> events, int time) {
		junctionList = map.getJunctions();
		fireTableDataChanged();
	}


	@Override
	public void onError(String err) {}
	
}