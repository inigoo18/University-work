package simulator.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.List;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

import simulator.control.Controller;
import simulator.model.Event;
import simulator.model.RoadMap;
import simulator.model.TrafficSimObserver;

public class StatusBar extends JPanel implements TrafficSimObserver{
	private JLabel _time, _events;
	
	StatusBar(Controller ctrl){
		
		JPanel mainPanel = new JPanel();
		//mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.X_AXIS));
		this.setLayout(new FlowLayout(FlowLayout.LEFT));
		add(mainPanel);

		JLabel timeLabel = new JLabel("Time: ");
		_time = new JLabel("0");
		_time.setPreferredSize( new Dimension(100, 20));
		mainPanel.add(timeLabel);
		mainPanel.add(_time);
		//mainPanel.add(Box.createRigidArea(new Dimension(200, 0)));
		
		JSeparator sep = new JSeparator(SwingConstants.VERTICAL);
		sep.setPreferredSize(new Dimension(40, 15));
		sep.setMaximumSize(new Dimension(40, 15));
		sep.setMinimumSize(new Dimension(40, 15));
		mainPanel.add(sep);
		
		_events = new JLabel("Welcome!");
		//_events.setPreferredSize( new Dimension(100, 20));
		mainPanel.add(_events);
		
		ctrl.addObserver(this);
	}
	
		
	
	@Override
	public void onAdvanceStart(RoadMap map, List<Event> events, int time) {
		if(!(map.getRoads().isEmpty() && map.getJunctions().isEmpty() && map.getVehicles().isEmpty())) {
			_time.setText("" + time);
		}
	}

	@Override
	public void onAdvanceEnd(RoadMap map, List<Event> events, int time) {}

	@Override
	public void onEventAdded(RoadMap map, List<Event> events, Event e, int time) {
		_events.setText("Event added (" + e.toString() + ")");
	}

	@Override
	public void onReset(RoadMap map, List<Event> events, int time) {}

	@Override
	public void onRegister(RoadMap map, List<Event> events, int time) {}

	@Override
	public void onError(String err) {
		_events.setText("Error occurred: " + err);
	}

}