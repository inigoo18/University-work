package simulator.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.*;

import simulator.model.Vehicle;

@SuppressWarnings("serial")
public class ChangeCO2ClassDialog extends JDialog {
	private static final int _WIDTH = 400;
	private static final int _HEIGHT = 150;
	
	
	private int _status;
	private JLabel textLabel, VehicleLabel, CO2Label, TicksLabel;
	private JComboBox<String> vehicleBox;
	private JComboBox<Integer> CO2List;
	private JSpinner tickSpinner;

	public ChangeCO2ClassDialog(Frame frame) {
		super(frame, true);
		_status = 0;
		initGUI();
	}

	public void initGUI() {
		setTitle("Change Contamination Class");
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());

		textLabel = new JLabel("<html>Schedule an event to change the CO2 class of a vehicle after a given number of simulation ticks from now.<html>");
		
		JPanel configPanel = new JPanel(); // has vehicle, co2 and ticks
		JPanel vehiclePanel = new JPanel();
		
		VehicleLabel = new JLabel("Vehicle:");
		vehicleBox = new JComboBox<String>();

		vehiclePanel.add(VehicleLabel);
		vehiclePanel.add(vehicleBox);
		
		JPanel CO2Panel = new JPanel();
		
		CO2Label = new JLabel("CO2 Class:");
		CO2List = new JComboBox<Integer>();
		for (int i = 0; i < 11; i++) { // total classes
			CO2List.addItem(i);
		}
		CO2List.setSelectedIndex(0);
		CO2Panel.add(CO2Label);
		CO2Panel.add(CO2List);
		
		JPanel ticksPanel = new JPanel();
		TicksLabel = new JLabel("Ticks:");
		tickSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 10000, 1));
		tickSpinner.setPreferredSize(new Dimension(60, 20));
		ticksPanel.add(TicksLabel);
		ticksPanel.add(tickSpinner);
		
		JPanel buttonsPanel = new JPanel(); // has cancel & ok
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				_status = 0;
				ChangeCO2ClassDialog.this.setVisible(false);
			}
		});
		JButton okButton = new JButton("Ok");
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (vehicleBox.getSelectedItem() != null) {
					_status = 1;
					ChangeCO2ClassDialog.this.setVisible(false);
				}
			}
		});
		buttonsPanel.add(cancelButton);
		buttonsPanel.add(okButton);
		configPanel.add(vehiclePanel);
		configPanel.add(CO2Panel);
		configPanel.add(ticksPanel);
		mainPanel.add(textLabel, BorderLayout.PAGE_START);
		mainPanel.add(configPanel, BorderLayout.CENTER);
		mainPanel.add(buttonsPanel, BorderLayout.PAGE_END);
		
		this.setContentPane(mainPanel);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setVisible(false);
	}
	
	
	public int open(List<Vehicle> vehicles) {
		for (Vehicle v: vehicles) {
			vehicleBox.addItem(v.getId());
		}
		
		int xParentLocation = getParent().getLocation().x;
		int yParentLocation = getParent().getLocation().y;
		int xParentSize = getParent().getSize().width;
		int yParentSize = getParent().getSize().height;
		
		setSize(_WIDTH, _HEIGHT);
		setLocation(xParentLocation + xParentSize / 2 - _WIDTH/2, yParentLocation + yParentSize / 2 - _HEIGHT / 2);
		setVisible(true);
		
		return _status;
	}
	
	String getSelectedVehicle() {
		return (String) vehicleBox.getSelectedItem();
	}
	
	int getSelectedContClass() {
		return (int) CO2List.getSelectedItem();
	}
	
	int getSelectedTicks() {
		return (int) tickSpinner.getValue();
	}
	
}