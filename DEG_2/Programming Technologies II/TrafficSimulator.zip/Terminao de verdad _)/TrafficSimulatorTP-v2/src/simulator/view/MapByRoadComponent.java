package simulator.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JComponent;

import simulator.control.Controller;
import simulator.model.Event;
import simulator.model.Junction;
import simulator.model.Road;
import simulator.model.RoadMap;
import simulator.model.TrafficSimObserver;
import simulator.model.Vehicle;
import simulator.model.VehicleStatus;
import simulator.model.Weather;

public class MapByRoadComponent extends JComponent implements TrafficSimObserver{

	
	private static final Color _BG_COLOR = Color.WHITE;
	private static final Color _ROAD = Color.BLACK;
	private static final Color _SRC_JUNCTION_COLOR = Color.BLUE;
	private static final Color _JUNCTION_LABEL_COLOR = new Color(200, 100, 0);
	private static final Color _DEST_JUNCTION_COLOR_CLOSED = Color.RED;
	private static final Color _DEST_JUNCTION_COLOR_OPEN = Color.GREEN;
	
	private static final int _JRADIUS = 10;
	
	private RoadMap _map;
	private List<Road> listRoads;
	
	private int numRoads;
	
	private Image _car;
	private List<Image> _co2;
	private List<Image> _weather;
	
	
	MapByRoadComponent(Controller ctrl){
		_weather = new ArrayList<Image>();
		_co2 = new ArrayList<Image>();
		this.setPreferredSize(new Dimension(300, 200));
		initGUI();
		ctrl.addObserver(this);
		
	}
	private void initGUI() {
		_weather.add(loadImage("sun.png"));
		_weather.add(loadImage("cloud.png"));
		_weather.add(loadImage("wind.png"));
		_weather.add(loadImage("rain.png"));
		_weather.add(loadImage("storm.png"));
		_co2.add(loadImage("cont_0.png"));
		_co2.add(loadImage("cont_1.png"));
		_co2.add(loadImage("cont_2.png"));
		_co2.add(loadImage("cont_3.png"));
		_co2.add(loadImage("cont_4.png"));
		_co2.add(loadImage("cont_5.png"));
		_car = loadImage("car_front.png");
	}
	
	public void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);
		Graphics2D g = (Graphics2D) graphics;
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		// clear with a background color
		g.setColor(_BG_COLOR);
		g.clearRect(0, 0, getWidth(), getHeight());

		if (_map == null || _map.getJunctions().size() == 0) {
			g.setColor(Color.red);
			g.drawString("No map yet!", getWidth() / 2 - 50, getHeight() / 2);
		} else {
			drawMap(g);
		}
	}
	
	private void drawMap(Graphics g) {
		drawRoads(g);
		drawVehicles(g);
		drawJunctions(g);
		drawWeather(g);
		drawCO2(g);
	}
	
	private void drawWeather(Graphics g) {
		int x = this.getWidth() - 90;
		for (int i = 0; i < listRoads.size(); i++) {
			Road r = listRoads.get(i);
			int y = (i+1) * 50;
			g.drawImage(_weather.get(getWeatherIdx(r.getWeather())), x, y, 32, 32, this);
		}
	}
	
	private int getWeatherIdx(Weather w) {
		if (w == Weather.SUNNY) {
			return 0;
		}
		else if (w == Weather.CLOUDY) {
			return 1;
		}
		else if (w == Weather.WINDY) {
			return 2;
		}
		else if (w == Weather.RAINY) {
			return 3;
		}
		else {
			return 4;
		}
	}
	
	private void drawCO2(Graphics g) {
		int x = this.getWidth() - 50;
		for (int i = 0; i < listRoads.size(); i++) {
			Road r = listRoads.get(i);
			int y = (i+1) * 50;
			int A = r.getTotalCO2();
			int B = r.getCO2Limit();
			int C = (int) Math.floor(Math.min((double)A/(1.0 + (double)B),1.0) / 0.19);
			g.drawImage(_co2.get(C), x, y, 32, 32, this);
		}

	}

	private void drawRoads(Graphics g) {
		int x1 = 50;
		int x2 = this.getWidth() - 100;
		g.setColor(_ROAD);
		for (int i = 0; i < listRoads.size(); i++) {
			Road r = listRoads.get(i);
			int y = (i+1) * 50;
			g.drawString(r.getId(), 5, y);
			g.drawLine(x1, y, x2, y);
		}

	}

	private void drawVehicles(Graphics g) {
		int x1 = 50;
		int x2 = getWidth() - 100;
		for (int i = 0; i < listRoads.size(); i++) {
			int y = (i+1) * 50;
			List<Vehicle> vehicles = _map.getVehicles();
			for(Vehicle v : vehicles) {
				if (v.getStatus() != VehicleStatus.ARRIVED && v.getRoad() == listRoads.get(i)) {
					int A = v.getLocation();
					int B = listRoads.get(i).getLength();
					int vehiPos =  x1 + (int) ((x2 - x1) * ((double) A/ (double)B));
					int vLabelColor = (int) (25.0 * (10.0 - (double) v.getContClass()));
					g.setColor(new Color(0, vLabelColor, 0));
					g.fillOval(vehiPos, y , 16, 16);
					g.drawImage(_car, vehiPos, y, 16, 16, this);
					g.drawString(v.getId(), vehiPos, y);
				}
			}
		}
	}

	private void drawJunctions(Graphics g) {
		for (int i = 0; i < listRoads.size(); i++){
			Road r = listRoads.get(i);
			int x1 = 50;
			int x2 = this.getWidth() - 100;
			int y = (i+1) * 50;
			g.setColor(_SRC_JUNCTION_COLOR);
			Junction srcJunct = listRoads.get(i).getSourceJunction();
			g.fillOval(x1, y, _JRADIUS, _JRADIUS); // src
			g.setColor(_JUNCTION_LABEL_COLOR);
			g.drawString(srcJunct.getId(), x1, y - 1);
			Junction destJunct = listRoads.get(i).getDestJunction();
			g.drawString(destJunct.getId(), x2, y - 1);
			Color junctColor = _DEST_JUNCTION_COLOR_CLOSED;
			int idx = r.getDestJunction().getGreenLightIndex();
			if (idx != -1 && r.equals(r.getDestJunction().getInRoads().get(idx))) {
				junctColor = _DEST_JUNCTION_COLOR_OPEN;
			}
			g.setColor(junctColor);
			g.fillOval(x2, y, _JRADIUS, _JRADIUS);
		}
	}
	
	private Image loadImage(String img) {
		Image i = null;
		try {
			return ImageIO.read(new File("resources/icons/" + img));
		} catch (IOException e) {
		}
		return i;
	}

	// this method is used to update the preffered and actual size of the component,
	// so when we draw outside the visible area the scrollbars show up
	
	
	

	@Override
	public void onAdvanceStart(RoadMap map, List<Event> events, int time) {
	}

	@Override
	public void onAdvanceEnd(RoadMap map, List<Event> events, int time) {
		_map = map;
		listRoads = map.getRoads();
		repaint();
	}

	@Override
	public void onEventAdded(RoadMap map, List<Event> events, Event e, int time) {
		_map = map;
		listRoads = map.getRoads();
		repaint();
	}

	@Override
	public void onReset(RoadMap map, List<Event> events, int time) {
		_map = map;
		listRoads = map.getRoads();
		repaint();
	}

	@Override
	public void onRegister(RoadMap map, List<Event> events, int time) {
		_map = map;
		listRoads = map.getRoads();
		repaint();
	}

	@Override
	public void onError(String err) {
	}

}
