package simulator.control;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import simulator.factories.Factory;
import simulator.model.Event;
import simulator.model.TrafficSimObserver;
import simulator.model.TrafficSimulator;

public class Controller {
	private TrafficSimulator _trafficSimulator;
	private Factory<Event> _eventsFactory;
	
	public Controller(TrafficSimulator sim, Factory<Event> eventsFactory) {
		if(sim != null) {
			if(eventsFactory != null) {
				_trafficSimulator = sim;
				_eventsFactory = eventsFactory;
			}
			else {
				throw new IllegalArgumentException("Events Factory is null");
			}
		}
		else {
			throw new IllegalArgumentException("Traffic simulator is null");
		}
	}
	
	public void loadEvents(InputStream in) {
		JSONObject jo = new JSONObject(new JSONTokener(in));
		JSONArray eventsList = jo.getJSONArray("events");
		
		for(int i = 0; i < jo.getJSONArray("events").length(); i++){
			_trafficSimulator.addEvent(_eventsFactory.createInstance(eventsList.getJSONObject(i)));
		}
	}
	
	public void run(int n, OutputStream out) {
		PrintStream p = new PrintStream(out);
		
		p.println("{\n  \"states\": [");
		for(int i = 0; i < n; i++) {
			_trafficSimulator.advance();
			p.println(_trafficSimulator.report());
		}
		p.print("]\n}");
	}
	
	public void run(int n) {
		for(int i = 0; i < n; i++) {
			_trafficSimulator.advance();
		}
	}
	
	public void reset() {
		_trafficSimulator.reset();
	}
	
	public void addObserver(TrafficSimObserver o) {
		_trafficSimulator.addObserver(o);
	}
	
	public void removeObserver(TrafficSimObserver o) {
		_trafficSimulator.removeObserver(o);
	}
	
	public void addEvent(Event e) {
		_trafficSimulator.addEvent(e);
	}
}