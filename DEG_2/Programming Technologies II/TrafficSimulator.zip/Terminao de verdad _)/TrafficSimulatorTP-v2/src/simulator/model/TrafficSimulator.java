package simulator.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONObject;

import simulator.misc.SortedArrayList;

public class TrafficSimulator implements Observable<TrafficSimObserver>{
	private RoadMap roadMap;
	private List<Event> events;
	private int time;
	private List<TrafficSimObserver> observers;
	
	public TrafficSimulator() {
		roadMap = new RoadMap();
		events = new SortedArrayList<Event>();
		observers = new ArrayList<TrafficSimObserver>();
		time = 0;
	}
	
	public void reset() {
		roadMap.reset();
		events.clear();
		time = 0;
		notifyReset();
	}
	
	public void addEvent(Event e) {
		if (e.getTime() > time) {
			events.add(e);
			notifyEventAdded(e);
		}
		else {
			throw new IllegalArgumentException("Inputed time equals current time");
		}
	}
	
	public void advance() {
		time++;
		notifyAdvanceStart();
		try {
			boolean done = false;
			Iterator<Event> it = events.iterator();
			while (!done && it.hasNext()) {
				Event e = it.next();
				if (e.getTime() == time) {
					e.execute(roadMap);
					it.remove();
				}
				else if (e.getTime() > time) {
					done = true;
				}
			}
			for(Junction j : roadMap.getJunctions()) {
				j.advance(time);
			}
			for(Road r : roadMap.getRoads()) {
				r.advance(time);
			}			
			notifyAdvanceEnd();
		} catch(Exception e) {
			notifyError(e.getMessage());
			throw e;
		}
	}
	
	public JSONObject report() {
		JSONObject jo = new JSONObject();
		
		jo.put("time", time);		
		jo.put("state", roadMap.report());
		
		return jo;
	}

	@Override
	public void addObserver(TrafficSimObserver o) {
		observers.add(o);
		notifyRegister();
	}

	@Override
	public void removeObserver(TrafficSimObserver o) {
		observers.remove(o);
	}
	
	private void notifyAdvanceStart() {
		for(TrafficSimObserver obs : observers) {
			obs.onAdvanceStart(roadMap, events, time);
		}
	}
	
	private void notifyAdvanceEnd() {
		for(TrafficSimObserver obs : observers) {
			obs.onAdvanceEnd(roadMap, events, time);
		}
	}
	
	private void notifyEventAdded(Event e) {
		for(TrafficSimObserver obs : observers) {
			obs.onEventAdded(roadMap, events, e, time);
		}
	}
	
	private void notifyReset() {
		for(TrafficSimObserver obs : observers) {
			obs.onReset(roadMap, events, time);
		}
	}
	
	private void notifyRegister() {
		for(TrafficSimObserver obs : observers) {
			obs.onRegister(roadMap, events, time);
		}
	}
	
	private void notifyError(String err) {
		for(TrafficSimObserver obs : observers) {
			obs.onError(err);
		}
	}
}