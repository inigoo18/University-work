package simulator.model;

import java.util.Iterator;
import java.util.List;
import simulator.misc.Pair;

public class SetContClassEvent extends Event {
	private List<Pair<String,Integer>> cs;

	public SetContClassEvent(int time, List<Pair<String,Integer>> cs) {
		super(time);
		if(cs != null) {
			this.cs = cs;
		}
		else {
			throw new IllegalArgumentException("Specify a valid vehicle/contClass list");
		}
	}
	
	@Override
	void execute(RoadMap map) {
		for(Pair<String, Integer> c : cs) {
			if(map.getVehicle(c.getFirst()) != null) {
				map.getVehicle(c.getFirst()).setContaminationClass(c.getSecond());
			}
			else {
				throw new IllegalArgumentException("Vehicle does not exist in the map");
			}
		}
	}
	
	public String toString() {
		String str = "Change CO2 class: [";
		
		Iterator<Pair<String, Integer>> iter = cs.iterator();
		int counter = 0;
		while (iter.hasNext()) {
			Pair<String, Integer> c = iter.next();
			if (counter > 0) {
				str += ", ";
			}
			str += "(" + c.getFirst() + "," + c.getSecond() + ")";
			counter++;
		}
		
		str += "]";
		
		return str;
	}
}
