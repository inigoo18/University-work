package simulator.model;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONObject;

public class Vehicle extends SimulatedObject {
	private List<Junction> itinerary; 
	private int maxSpeed;
	private int speed;
	private VehicleStatus status;
	private Road road;
	private int location;
	private int contClass; 		// HOW MUCH CONTAMINATION
	private int totalCont;
	private int totalDistance;
	private int itineraryIndex; // Last junction I have been to
	
	Vehicle(String id, int maxSpeed, int contClass, List<Junction> itinerary) {
		super(id);
		speed = 0;
		totalCont = 0;
		itineraryIndex = 0;
		status = VehicleStatus.PENDING;
		setContaminationClass(contClass);
		if (maxSpeed >= 0) {
			this.maxSpeed = maxSpeed;
		}
		else {
			throw new IllegalArgumentException("Invalid speed");
		}
		if (itinerary.size() > 1) {
			this.itinerary = Collections.unmodifiableList(new ArrayList<>(itinerary));
		}
		else {
			throw new IllegalArgumentException("Not enough Junctions");
		}
	}
	
	public List<Junction> getItinerary(){
		return Collections.unmodifiableList(itinerary);
	}
	
	public int getLocation() {
		return location;
	}
	
	public int getSpeed() {
		return speed;
	}

	public int getMaxSpeed() {
		return maxSpeed;
	}
	
	public int getContClass() {
		return contClass;
	}
	
	public VehicleStatus getStatus() {
		return status;
	}
	
	public Road getRoad() {
		return road;
	}
	
	public int getTotalCont() {
		return totalCont;
	}
	
	public int getDistance() {
		return totalDistance;
	}
	
	public int getIdx() {
		return itineraryIndex;
	}
	
	void moveToNextRoad() {
		if(status.equals(VehicleStatus.PENDING) || status.equals(VehicleStatus.WAITING)) {
			if(status.equals(VehicleStatus.WAITING)) {
				road.exit(this);
				location = 0;
				itineraryIndex++;
			}
			if (itineraryIndex < itinerary.size() - 1) {
				road = itinerary.get(itineraryIndex).roadTo(itinerary.get(itineraryIndex + 1));
				road.enter(this);
				status = VehicleStatus.TRAVELING;
			}
			else {
				status = VehicleStatus.ARRIVED;
				speed = 0;
			}
		}
		else {
			throw new IllegalArgumentException("Cannot change road for the given vehicle");
		}
	}
	
	@Override
	void advance(int time) {
		if (status.equals(VehicleStatus.TRAVELING)) {
			int prevLoc = location;
			if(location + speed < road.getLength()) {
				location += speed;
			}
			else {
				location = road.getLength();
			}
			int addedCont = contClass * (location - prevLoc);
			totalDistance += (location - prevLoc);
			totalCont += addedCont;
			road.addContamination(addedCont);
			if(location == road.getLength()) {
				status = VehicleStatus.WAITING;
				speed = 0;
				itinerary.get(itineraryIndex + 1).enter(road, this);
			}
		}
	}

	void setSpeed(int s) {
		if(status != VehicleStatus.WAITING) {
			if (s >= 0) {
				if (s < maxSpeed) {
					speed = s; 
				}
				else{
					speed = maxSpeed;
				}
			}
			else {
				throw new IllegalArgumentException("Speed not valid");
			}
		}
	}
	void setContaminationClass(int c) {
		if(c >= 0 && c <= 10) {
			contClass = c;
		}
		else {
			throw new IllegalArgumentException();
		}
	}
	
	@Override
	public JSONObject report() {
		JSONObject jo = new JSONObject();
		jo.put("id", _id);
		jo.put("speed", speed);
		jo.put("distance", totalDistance);
		jo.put("co2", totalCont);
		jo.put("class", contClass);
		jo.put("status", status.name());
		if(status.equals(VehicleStatus.TRAVELING) || status.equals(VehicleStatus.WAITING)) {
			jo.put("road", road.getId());
			jo.put("location", location);
		}
		return jo;
	}
}