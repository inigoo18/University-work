package simulator.model;

import java.awt.RenderingHints;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public class Junction extends SimulatedObject {
	private List<Road> incomingRoads;
	private Map<Junction, Road> outgoingRoads;
	private List<List<Vehicle>> listQueues;
	private Map<Road, List<Vehicle>> queuesTable;
	private int greenIdx;
	private int lastSwitch;
	private LightSwitchingStrategy lsStrategy;
	private DequeuingStrategy dqStrategy;
	private int x;
	private int y;
	
	Junction(String id, LightSwitchingStrategy lsStrategy, DequeuingStrategy dqStrategy, int xCoor, int yCoor) {
		super(id);
		if (lsStrategy == null || dqStrategy == null) {
			throw new IllegalArgumentException("Specify valid Strategies");
		}
		else if (xCoor < 0 || yCoor < 0) {
			throw new IllegalArgumentException("Coordinates must be positive");
		}
		else {
			incomingRoads = new ArrayList<Road>();
			outgoingRoads = new HashMap<Junction, Road>();
			listQueues = new ArrayList<List<Vehicle>>();
			queuesTable = new HashMap<Road, List<Vehicle>>();
			greenIdx = -1;
			lastSwitch = 0;
			this.lsStrategy = lsStrategy;
			this.dqStrategy = dqStrategy;
			x = xCoor;
			y = yCoor;
		}
	}
	
	void addIncomingRoad(Road r) {
		if (r.getDestJunction().equals(this)) {
			incomingRoads.add(r);
			List<Vehicle> q = new LinkedList<Vehicle>();
			listQueues.add(q);
			queuesTable.put(r, q);
		}
		else {
			throw new IllegalArgumentException("Outcoming road does not match");
		}
	}
	
	void addOutGoingRoad(Road r) {
		if (!outgoingRoads.containsKey(r.getDestJunction()) && r.getSourceJunction().equals(this)) {
			outgoingRoads.put(r.getDestJunction(), r);
		}
		else {
			throw new IllegalArgumentException("Specify a valid outcoming road");
		}
	}
	
	void enter(Road r, Vehicle v) {
		queuesTable.get(r).add(v);
	}
	
	Road roadTo(Junction j) {
		return outgoingRoads.get(j);
	}
	
	@Override
	void advance(int time) {
		if (greenIdx != -1) {
			List<Vehicle> listVehicle = listQueues.get(greenIdx);
			for (Vehicle v : dqStrategy.dequeue(listVehicle)) {
				v.moveToNextRoad();
				listVehicle.remove(v);
			}
		}
		int aux = greenIdx;
		greenIdx = lsStrategy.chooseNextGreen(incomingRoads, listQueues, greenIdx, lastSwitch, time);
		if (greenIdx != aux) {
			lastSwitch = time;
		}
	}
	
	@Override
	public JSONObject report() {
		JSONObject jo = new JSONObject();
		jo.put("id", _id);
		jo.put("green", greenIdx != -1 ? incomingRoads.get(greenIdx).getId() : "none");
		JSONArray ja = new JSONArray();
		for (Road r : incomingRoads) {
			JSONObject jq = new JSONObject();
			jq.put("road", r.getId());
			JSONArray ja1 = new JSONArray();
			for (Vehicle v : queuesTable.get(r)) {
				ja1.put(v.getId());
			}
			jq.put("vehicles", ja1);
			ja.put(jq);
		}
		jo.put("queues", ja);
		return jo;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public int getGreenLightIndex() {
		return greenIdx;
	}
	
	public List<Road> getInRoads() {
		return Collections.unmodifiableList(incomingRoads);
	}
	
	public Map<Road, List<Vehicle>> getQueues(){
		return Collections.unmodifiableMap(queuesTable);
	}
}