package simulator.model;

public class CityRoad extends Road {
	
	CityRoad(String id, Junction srcJunc, Junction destJunc, int maxSpeed, int contLimit, int length, Weather weather) {
		super(id, srcJunc, destJunc, maxSpeed, contLimit, length, weather);
		sunnyFactor = 2;
		cloudyFactor = 2;
		rainyFactor = 2;
		windyFactor = 10;
		stormFactor = 10;
	}

	@Override
	void reduceTotalContamination() {
		totalContamination -= getWeatherFactor(weatherCondition);
		if (totalContamination < 0) {
			totalContamination = 0;
		}
	}

	@Override
	void updateSpeedLimit() {
		currentSpeed = maximumSpeed;
	}

	@Override
	int calculateVehicleSpeed(Vehicle v) {
		return (int)(((11.0 - v.getContClass()) / 11.0) * maximumSpeed);
	}
	
}
