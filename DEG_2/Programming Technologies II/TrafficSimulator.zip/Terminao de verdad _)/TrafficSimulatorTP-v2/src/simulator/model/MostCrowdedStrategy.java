package simulator.model;

import java.util.List;

public class MostCrowdedStrategy implements LightSwitchingStrategy {
	private int timeSlot;
	public MostCrowdedStrategy(int timeSlot) {
		this.timeSlot = timeSlot;
	}
	@Override
	public int chooseNextGreen(List<Road> roads, List<List<Vehicle>> qs, int currGreen, int lastSwitchingTime,
			int currTime) {
		if (roads.isEmpty()) {
			return -1;
		}
		else if (currGreen == -1) {
			return getMax(0, qs);
		}
		else if (currTime - lastSwitchingTime < timeSlot) {
			return currGreen;
		}
		else {
			return getMax(currGreen + 1 % qs.size(), qs);
		}
	}
	private int getMax(int pos, List<List<Vehicle>> qs) {
		int max = 0;
		int idx = 0;
		int start = pos;
		int i = start;
		do {
			if (qs.get(i).size() > max) { // circular search starting in currGreen + 1 % qs.size
				max = qs.get(i).size();
				idx = i;
			}
			i = (i + 1) % qs.size();
		} while (i != start);
		return idx;
	}
}