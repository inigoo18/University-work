package simulator.model;

public class InterCityRoad extends Road {	
	InterCityRoad(String id, Junction srcJunc, Junction destJunc, int maxSpeed, int contLimit, int length, Weather weather) {
		super(id, srcJunc, destJunc, maxSpeed, contLimit, length, weather);
		sunnyFactor = 2;
		cloudyFactor = 3;
		rainyFactor = 10;
		windyFactor = 15;
		stormFactor = 20;
	}

	@Override
	void reduceTotalContamination() {
		totalContamination = (int)(((100.0 - getWeatherFactor(weatherCondition)) / 100.0 ) * totalContamination);
	}

	@Override
	void updateSpeedLimit() {
		if (totalContamination > contAlarmLimit) {
			currentSpeed = (int)(maximumSpeed * 0.5);
		}
		else {
			currentSpeed = maximumSpeed;
		}
		
	}

	@Override
	int calculateVehicleSpeed(Vehicle v) {
		if (weatherCondition.equals(Weather.STORM)){
			return (int)(currentSpeed * 0.8);
		}
		else {
			return currentSpeed;
		}
	}
}