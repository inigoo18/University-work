package simulator.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

public class RoadMap {
	private List <Junction> listJunctions;
	private List <Road> listRoads;
	private List <Vehicle> listVehicles;
	private Map<String, Junction> junctionMap;
	private Map<String, Road> roadMap;
	private Map <String, Vehicle> vehicleMap;
	
	public RoadMap(){
		listJunctions = new ArrayList<Junction>();
		listRoads = new ArrayList<Road>();
		listVehicles = new ArrayList<Vehicle>();
		junctionMap = new HashMap<String, Junction>();
		roadMap = new HashMap<String, Road>();
		vehicleMap = new HashMap<String, Vehicle>();
	}
	
	void addJunction(Junction j) {
		if (!junctionMap.containsKey(j.getId())) {
			listJunctions.add(j);
			junctionMap.put(j.getId(), j);
		}
		else{
			throw new IllegalArgumentException("Junction already exists");
		}
	}
	
	void addRoad(Road r) {
		if (!roadMap.containsKey(r.getId())) {
			if( junctionMap.containsKey(r.getSourceJunction().getId()) && junctionMap.containsKey(r.getDestJunction().getId())) {
				listRoads.add(r);
				roadMap.put(r.getId(), r);
			}
			else{
				throw new IllegalArgumentException("Destination and/or source junctions do not exist");
			}
		}
		else {
			throw new IllegalArgumentException("Road already exists");
		}
	}
	
	void addVehicle(Vehicle v) {
		boolean validItinerary = true;
		
		if (!vehicleMap.containsKey(v.getId())) {
			Iterator<Junction> iter1 = v.getItinerary().iterator();
			Iterator<Junction> iter2 = v.getItinerary().iterator();
			iter2.next();
			while(iter2.hasNext() && validItinerary) {
				Junction j1 = iter1.next();
				Junction j2 = iter2.next();								
				if(j1.roadTo(j2) == null) {
					validItinerary = false;
				}
			}
			if(validItinerary) {
				listVehicles.add(v);
				vehicleMap.put(v.getId(), v);
			}
			else {
				throw new IllegalArgumentException("Vehicle itinerary not valid");
			}
		}
		else {
			throw new IllegalArgumentException("Vehicle already exists");
		}
		
	}
	
	public Junction getJunction(String id) {
		return junctionMap.get(id);
	}
	
	public Road getRoad(String id) {
		return roadMap.get(id);
	}
	
	public Vehicle getVehicle(String id) {
		return vehicleMap.get(id);
	}
	
	public List<Junction> getJunctions(){
		return Collections.unmodifiableList(listJunctions);
	}
	
	public List <Road> getRoads(){
		return Collections.unmodifiableList(listRoads);
	}
	
	public List<Vehicle> getVehicles(){
		return Collections.unmodifiableList(listVehicles);
	}
	
	void reset() {
		listJunctions.clear();
		listRoads.clear();
		listVehicles.clear();
		junctionMap.clear();
		roadMap.clear();
		vehicleMap.clear();
	}
	
	public JSONObject report() {
		JSONObject jo = new JSONObject();
		JSONArray ju = new JSONArray();
		JSONArray ro = new JSONArray();
		JSONArray ve = new JSONArray();
		for(Junction j : listJunctions) {
			ju.put(j.report());
		}
		for(Road r : listRoads) {
			ro.put(r.report());
		}
		for(Vehicle v : listVehicles) {
			ve.put(v.report());
		}
		jo.put("junctions", ju);
		jo.put("roads", ro);
		jo.put("vehicles", ve);
		return jo;
	}
}