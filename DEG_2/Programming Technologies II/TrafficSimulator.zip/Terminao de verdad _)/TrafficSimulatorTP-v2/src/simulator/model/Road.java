package simulator.model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public abstract class Road extends SimulatedObject {
	protected int length, maximumSpeed, currentSpeed, contAlarmLimit, totalContamination;
// currentSpeed is the current speed limit of the road.
	private Junction sourceJunction;
	private Junction destJunction;
	protected Weather weatherCondition;
	private List<Vehicle> vehicleList;
	private Comparator<Vehicle> comp;

	protected int sunnyFactor, cloudyFactor, rainyFactor, windyFactor, stormFactor;

	Road(String id, Junction srcJunc, Junction destJunc, int maxSpeed, int contLimit, int length, Weather weather) {
		super(id);
		if (maxSpeed < 0 || contLimit < 0 || length < 0 || srcJunc == null || destJunc == null || weather == null) {
			throw new IllegalArgumentException("Invalid constructor arguments for class Road");
		} else {
			sourceJunction = srcJunc;
			destJunction = destJunc;
			destJunc.addIncomingRoad(this);
			srcJunc.addOutGoingRoad(this);
			this.length = length;
			this.maximumSpeed = maxSpeed;
			this.currentSpeed = maxSpeed;
			this.contAlarmLimit = contLimit;
			this.totalContamination = 0;
			weatherCondition = weather;
			vehicleList = new ArrayList<Vehicle>();
			comp = new Comparator<Vehicle>() {
				@Override
				public int compare(Vehicle o1, Vehicle o2) {
					if (o1.getLocation() == o2.getLocation()) {
						return 0;
					} else if (o1.getLocation() > o2.getLocation()) {
						return -1;
					} else {
						return 1;
					}
				}
			};
		}
	}

	public Junction getDestJunction() {
		return destJunction;
	}

	public Junction getSourceJunction() {
		return sourceJunction;
	}

	public int getTotalCO2() {
		return totalContamination;
	}

	public int getCO2Limit() {
		return contAlarmLimit;
	}

	public int getLength() {
		return length;
	}
	
	public Weather getWeather() {
		return weatherCondition;
	}
	
	public int getMaxSpeed() {
		return maximumSpeed;
	}
	
	public int getCurrSpeed() {
		return currentSpeed;
	}

	void enter(Vehicle v) {
		if (v.getSpeed() == 0 && v.getLocation() == 0) {
			vehicleList.add(v);
		} else {
			throw new IllegalArgumentException("Invalid vehicle for entering the road");
		}
	}

	void exit(Vehicle v) {
		vehicleList.remove(v);
	}

	void setWeather(Weather w) {
		if (w != null) {
			weatherCondition = w;
		} else {
			throw new IllegalArgumentException("Weather cannot be null");
		}
	}

	void addContamination(int c) {
		if (c >= 0) {
			totalContamination += c;
		} else {
			throw new IllegalArgumentException("Contamination cannot be negative");
		}
	}

	int getWeatherFactor(Weather w) {
		if (w.equals(Weather.SUNNY)) {
			return sunnyFactor;
		} else if (w.equals(Weather.CLOUDY)) {
			return cloudyFactor;
		} else if (w.equals(Weather.RAINY)) {
			return rainyFactor;
		} else if (w.equals(Weather.WINDY)) {
			return windyFactor;
		} else {
			return stormFactor;
		}
	}

	abstract void reduceTotalContamination();

	abstract void updateSpeedLimit();

	abstract int calculateVehicleSpeed(Vehicle v);

	@Override
	void advance(int time) {
		reduceTotalContamination();
		updateSpeedLimit();
		for (Vehicle v : vehicleList) {
			v.setSpeed(calculateVehicleSpeed(v));
			v.advance(time);
		}
		vehicleList.sort(comp);
	}

	@Override
	public JSONObject report() {
		JSONObject jo = new JSONObject();

		jo.put("id", _id);
		jo.put("speedlimit", currentSpeed);
		jo.put("weather", weatherCondition);
		jo.put("co2", totalContamination);

		JSONArray ja = new JSONArray();
		for (Vehicle v : vehicleList) {
			ja.put(v.getId());
		}

		jo.put("vehicles", ja);

		return jo;
	}

}