package simulator.model;

import java.util.Iterator;
import java.util.List;
import simulator.misc.Pair;

public class SetWeatherEvent extends Event {
	private List<Pair<String,Weather>> ws;

	public SetWeatherEvent(int time, List<Pair<String,Weather>> ws) {
		super(time);
		if (ws != null) {
			this.ws = ws;
		}
		else {
			throw new IllegalArgumentException("Specify a valid road/wather list");
		}
	}
	
	@Override
	void execute(RoadMap map) {
		for(Pair<String, Weather> w : ws) {
			if(map.getRoad(w.getFirst()) != null) {
				map.getRoad(w.getFirst()).setWeather(w.getSecond());
			}
			else {
				throw new IllegalArgumentException("Road does not exist in the map");
			}
		}
	}

	
	public String toString() {
		String str = "Change Weather: [";
		
		Iterator<Pair<String, Weather>> iter = ws.iterator();
		int counter = 0;
		while (iter.hasNext()) {
			if (counter > 0) {
				str += ", ";
			}
			Pair<String, Weather> w = iter.next();
			str += "(" + w.getFirst() + "," + w.getSecond() + ")";
			counter++;
		}
		
		str += "]";
		
		return str;
	}
}
