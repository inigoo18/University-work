package simulator.factories;


import org.json.JSONObject;

import simulator.model.Event;
import simulator.model.NewRoadEvent;
import simulator.model.Weather;

public abstract class NewRoadEventBuilder extends Builder<Event> {
	protected String _id, _src, _dest;
	protected int _time, _length, _co2limit, _maxspeed;
	protected Weather _weather;
	
	NewRoadEventBuilder(String name) {
		super(name);
	}
	
	abstract NewRoadEvent createInstance();
	
	protected Event createTheInstance(JSONObject data) {
		_time = data.getInt("time");
		_id = data.getString("id");
		_src = data.getString("src");
		_dest = data.getString("dest");
		_length = data.getInt("length");
		_co2limit = data.getInt("co2limit");
		_maxspeed = data.getInt("maxspeed");
		_weather = Weather.valueOf(data.getString("weather"));
		
		return createInstance();
	}
}