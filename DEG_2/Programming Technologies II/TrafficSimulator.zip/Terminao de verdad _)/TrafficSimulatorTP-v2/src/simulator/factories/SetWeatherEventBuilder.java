package simulator.factories;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.misc.Pair;
import simulator.model.Event;
import simulator.model.SetWeatherEvent;
import simulator.model.Weather;

public class SetWeatherEventBuilder extends Builder<Event>{

	public SetWeatherEventBuilder() {
		super("set_weather");
	}

	@Override
	protected SetWeatherEvent createTheInstance(JSONObject data) {
		
		List<Pair<String, Weather>> rw = new ArrayList<Pair<String, Weather>>();
		JSONArray roads = data.getJSONArray("info");
		
		for(int i = 0; i < roads.length(); i++) {
			JSONObject road = roads.getJSONObject(i);
			rw.add(new Pair<String, Weather>(road.getString("road"), Weather.valueOf(road.getString("weather"))));
		}
		
		return new SetWeatherEvent(data.getInt("time"), rw);
	}
}
