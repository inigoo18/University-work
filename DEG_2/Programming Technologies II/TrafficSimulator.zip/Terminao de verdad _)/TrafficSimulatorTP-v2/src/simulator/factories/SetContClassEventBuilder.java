package simulator.factories;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.misc.Pair;
import simulator.model.Event;
import simulator.model.SetContClassEvent;
public class SetContClassEventBuilder extends Builder<Event>{

	public SetContClassEventBuilder() {
		super("set_cont_class");
	}

	@Override
	protected SetContClassEvent createTheInstance(JSONObject data) {
		List<Pair<String, Integer>> vc = new ArrayList<Pair<String, Integer>>();
		JSONArray vehicles = data.getJSONArray("info");
		
		for(int i = 0; i < vehicles.length(); i++) {
			JSONObject vehicle = vehicles.getJSONObject(i);
			vc.add(new Pair<String, Integer>(vehicle.getString("vehicle"),vehicle.getInt("class")));
		}
		
		return new SetContClassEvent(data.getInt("time"), vc);
	}

}
