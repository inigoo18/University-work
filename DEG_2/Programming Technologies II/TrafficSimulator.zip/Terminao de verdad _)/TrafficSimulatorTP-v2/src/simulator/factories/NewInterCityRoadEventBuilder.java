package simulator.factories;

import org.json.JSONObject;

import simulator.model.Event;
import simulator.model.NewInterCityRoadEvent;
import simulator.model.NewRoadEvent;
import simulator.model.Weather;

public class NewInterCityRoadEventBuilder extends NewRoadEventBuilder {
	
	public NewInterCityRoadEventBuilder() {
		super("new_inter_city_road");
	}

	@Override
	NewRoadEvent createInstance() {
		return new NewInterCityRoadEvent(_time, _id, _src, _dest, _length, _co2limit, _maxspeed, _weather);
	}
}
