package simulator.factories;

import simulator.model.NewCityRoadEvent;
import simulator.model.NewRoadEvent;

public class NewCityRoadEventBuilder extends NewRoadEventBuilder {
	
	public NewCityRoadEventBuilder() {
		super("new_city_road");
	}

	@Override
	NewRoadEvent createInstance() {
		return new NewCityRoadEvent(_time, _id, _src, _dest, _length, _co2limit, _maxspeed, _weather);
	}
}
